# movie-explorer

## домен
https://th3arsk.diploma.nomoredomainsmonster.ru

## поддомен
https://api.th3arsk.diploma.nomoredomainsmonster.ru/

## pull-request
https://github.com/th3arsk/movies-explorer-frontend/compare/main...level-3

## макет
light-4

## ссылка на макет
https://www.figma.com/file/6FMWkB94wE7KTkcCgUXtnC/%D0%94%D0%B8%D0%BF%D0%BB%D0%BE%D0%BC%D0%BD%D1%8B%D0%B9-%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82?type=design&node-id=1-2798&mode=dev
