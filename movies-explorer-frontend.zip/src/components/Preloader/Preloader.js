import "./Preloader.css"

function Preloader() {
  return (
    <div className="mk-spinner-wrap">
      <div className="mk-spinner-ring"></div>
    </div>
  )
}

export default Preloader;
